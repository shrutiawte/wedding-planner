package com.example.wedding_planner_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeddingPlannerManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
