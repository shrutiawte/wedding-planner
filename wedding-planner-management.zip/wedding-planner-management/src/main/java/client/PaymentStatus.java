package client;

public enum PaymentStatus {
    PENDING,
    COMPLETED
}

