package client;

public enum VendorStatus {
    AVAILABLE,
    UNAVAILABLE
}

