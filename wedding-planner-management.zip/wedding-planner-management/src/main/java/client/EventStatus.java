package client;

public enum EventStatus {
    UPCOMING,
    COMPLETED
}
